I put this data together in the hope that others might find it useful. The copyright rests with the Crown (as shown below) so please note the licence information below.

Alasdair Rae
25 March 2015


ORDNANCE SURVEY DATA LICENCE

Your use of OS OpenData is subject to the terms at http://os.uk/opendata/licence

Contains Ordnance Survey data � Crown copyright and database right 2015
